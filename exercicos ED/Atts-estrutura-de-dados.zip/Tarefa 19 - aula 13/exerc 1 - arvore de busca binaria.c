//Qual a árvore de busca binária formada pela inserção dos itens 7, 4, 6, 11, 8, 2, 5, 0, 10, 3, 1 e 9 nessa ordem?

                                    7
                                  /   \
                                 4     11
                                / \    / \
                               2   6  8   10
                              /   /    \
                             0   5      9
                                /
                               3
                              /
                             1

/* Altere o programa do exercício anterior para testar as demais operações em dicionários.*/



#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef char* Chave;
typedef char* Valor;

typedef struct map {
    Chave chave;
    Valor valor;
    struct map *prox;
} *Map;

typedef struct dic {
    int tam;
    Map *vet;
} *Dic;

Dic dic(int m);
Map no_map(Chave c, Valor v, Map p);
void insd(Chave c, Valor v, Dic d);
void insm(Chave c, Valor v, Map *M);
void remd(Chave c, Dic d);
void remm(Chave c, Map *M);
int pertd(Chave c, Valor v, Dic d);
int pertm(Chave c, Valor v, Map M);
void exibed(Dic d);
void exibem(Map M);
unsigned hash(Chave c, int m);
void destroid(Dic *d);
void destroimr(Map M);

Map no_map(Chave c, Valor v, Map p) {
    Map n = malloc(sizeof(struct map));
    n->chave = strdup(c);
    n->valor = strdup(v);
    n->prox = p;
    return n;
}

void destroimr(Map M) {
    if (M) {
        Map aux = M->prox;
        free(M->chave); 
        free(M->valor); 
        free(M);
        destroimr(aux);
    }
}

void destroid(Dic *d) {
    for (int i = 0; i < (*d)->tam; i++)
        destroimr((*d)->vet[i]);
    free((*d)->vet);
    free(*d);
    *d = NULL;
}

Dic dic(int m) {
    Dic d = malloc(sizeof(struct dic));
    d->tam = m;
    d->vet = malloc(m * sizeof(Map));
    for (int i = 0; i < m; i++)
        d->vet[i] = NULL;
    return d;
}

void insd(Chave c, Valor v, Dic d) {
    insm(c, v, &d->vet[hash(c, d->tam)]);
}

void insm(Chave c, Valor v, Map *M) {
    while (*M && strcmp(c, (*M)->chave) > 0)
        M = &(*M)->prox;
    if (*M && strcmp(c, (*M)->chave) == 0)
        (*M)->valor = strdup(v);
    else
        *M = no_map(c, v, *M);
}

void remd(Chave c, Dic d) {
    remm(c, &d->vet[hash(c, d->tam)]);
}

void remm(Chave c, Map *M) {
    while (*M && strcmp(c, (*M)->chave) > 0)
        M = &(*M)->prox;
    if (*M && strcmp(c, (*M)->chave) == 0) {
        Map n = *M;
        *M = n->prox;
        free(n->chave);
        free(n->valor);
        free(n);
    }
}

int pertd(Chave c, Valor v, Dic d) {
    return pertm(c, v, d->vet[hash(c, d->tam)]);
}

int pertm(Chave c, Valor v, Map M) {
    while (M && strcmp(c, M->chave) > 0)
        M = M->prox;
    if (M && strcmp(c, M->chave) == 0) {
        strcpy(v, M->valor);
        return 1;
    }
    return 0;
}

void exibed(Dic d) {
    for (int i = 0; i < d->tam; i++) {
        printf("%d: ", i);
        exibem(d->vet[i]);
    }
}

void exibem(Map M) {
    printf("[");
    while (M) {
        printf("(%s,%s)", M->chave, M->valor);
        if (M->prox)
            printf(",");
        M = M->prox;
    }
    printf("]\n");
}

unsigned hash(Chave c, int m) {
    unsigned s = 0;
    for (int i = 0; c[i]; i++)
        s += (i + 1) * c[i];
    return (s % m);
}

int main(void) {
    Dic D = dic(3);
    insd("bat", "morcego", D);
    insd("pig", "porco", D);
    insd("cat", "gato", D);
    insd("dog", "cachorro", D);
    insd("cow", "vaca", D);
    exibed(D);
  
    remd("pig", D);
    exibed(D);

    pertd("bat","morcego", D);
    
    destroid(&D);
    return 0;
}

/* Altere o programa do exercício anterior para testar as demais operações em dicionários*/











#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef int Chave;
typedef char *Valor;

typedef struct map {
    Chave chave;
    Valor valor;
    struct map *prox;
} *Map;

typedef struct dic {
    int tam;
    Map *vet;
} *Dic;

Dic dic(int m);
Map no_map(Chave c, Valor v, Map p);
void insd(Chave c, Valor v, Dic d);
void insm(Chave c, Valor v, Map *M);
void remd(Chave c, Dic d);
void remm(Chave c, Map *M);
int pertd(Chave c, Valor v, Dic d);
int pertm(Chave c, Valor v, Map M);
void exibed(Dic d);
void exibem(Map M);
int hash(int c, int m);
void destroid(Dic *d);
int destroimr( Map M);

Map no_map(Chave c, Valor v, Map p) {
    Map n = malloc(sizeof(struct map));
    n->chave = c;
    n->valor = strdup(v); 
    n->prox = p;
    return n;
}


void destroid(Dic *d) {
for(int i=0; i<(*d)->tam; i++)
destroimr(&(*d)->vet[i]);
free(*d);
*d = NULL;
}

int destroimr( Map M) {
  if(M){
    Map aux = M;
    free(aux);
    destroimr(M->prox);
  } else{
    return 0;
  }
}



Dic dic(int m) {
    Dic d = malloc(sizeof(struct dic));
    d->tam = m;
    d->vet = malloc(m * sizeof(Map));
    for (int i = 0; i < m; i++)
        d->vet[i] = NULL;
    return d;
}

void insd(Chave c, Valor v, Dic d) {
    insm(c, v, &d->vet[hash(c, d->tam)]);
}

void insm(Chave c, Valor v, Map *M) {
    while (*M && c > (*M)->chave)
        M = &(*M)->prox;
    if (*M && c == (*M)->chave)
        (*M)->valor = strdup(v); 
    else
        *M = no_map(c, v, *M);
}

void remd(Chave c, Dic d) {
    remm(c, &d->vet[hash(c, d->tam)]);
}

void remm(Chave c, Map *M) {
    while (*M && c > (*M)->chave)
        M = &(*M)->prox;
    if (*M == NULL || c != (*M)->chave)
        return;
    Map n = *M;
    *M = n->prox;
    free(n->valor); 
    free(n);
}

int pertd(Chave c, Valor v, Dic d) {
    return pertm(c, v, d->vet[hash(c, d->tam)]);
}

int pertm(Chave c, Valor v, Map M) {
    while (M && c > M->chave)
        M = M->prox;
    if (M && c == M->chave) {
        strcpy(v, M->valor);
        return 1;
    }
    return 0;
}

void exibed(Dic d) {
    for (int i = 0; i < d->tam; i++) {
        printf("%d: ", i);
        exibem(d->vet[i]);
    }
}

void exibem(Map M) {
    printf("[");
    while (M) {
        printf("(%d,%s)", M->chave, M->valor);
        if (M->prox)
            printf(",");
        M = M->prox;
    }
    printf("]\n");
}

int hash(int c, int m) {
    return (c % m);
}

int main(void) {
    Dic D = dic(5);
    insd(59, "Bia", D);
    insd(48, "Eva", D);
    insd(25, "Ivo", D);
    insd(17, "Ana", D);
    insd(83, "Leo", D);
    exibed(D);

    remd(83, D);
    exibed(D);

    pertd(16,"Lua", D);
    destroid(&D);

    return 0;


}



/* Complete e execute o programa a seguir.
#include <stdio.h>
#include <stdlib.h>

void ins(Item x, Lista *L) {
while( *L != NULL && (*L)->item < x )
L = &(*L)->prox;
*L = no(x,*L);
}

...
int main(void) {
Lista I = NULL;
ins(4,&I);
ins(1,&I);
ins(3,&I);
ins(5,&I);
ins(2,&I);
exibe(I);
return 0;
}

*/

#include <stdio.h>
#include <stdlib.h>

typedef int Item;

typedef struct no {
    Item item;
    struct no *prox;
} *Lista;



void exibe(Lista L) {
printf("[");
if (L != NULL) {
    printf("%d", L->item);
    L = L->prox;
    while (L != NULL) {
        printf(",%d", L->item);
        L = L->prox;
    }
}
printf("]\n");
}


void ins(Item x, Lista *L) {
    Lista novo = malloc(sizeof(struct no));
    if (novo == NULL) {
        printf("Erro: falha na alocação de memória\n");
        exit(EXIT_FAILURE);
    }
    novo->item = x;
    novo->prox = NULL;

    while (*L != NULL && (*L)->item < x) {
        L = &(*L)->prox;
    }


    novo->prox = *L;
    *L = novo;
}

int main(void) {
    Lista I = NULL;
    ins(4,&I);
    ins(1,&I);
    ins(3,&I);
    ins(5,&I);
    ins(2,&I);
    exibe(I);
    return 0;
}
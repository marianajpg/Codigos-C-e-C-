/* Crie a função recursiva oec(L), que verifica se L é uma lista ordenada de forma estritamente
crescente (i.e., cada item é menor que item seguinte na lista).*/


  #include <stdio.h>
  #include <stdlib.h>

  typedef int Item;

  typedef struct no {
      Item item;
      struct no *prox;
  } *Lista;

  void exibe(Lista L) {
      printf("[");
      if (L != NULL) {
          printf("%d", L->item);
          L = L->prox;
          while (L != NULL) {
              printf(", %d", L->item);
              L = L->prox;
          }
      }
      printf("]\n");
  }


int oec(Lista L) {
    if (L == NULL || L->prox == NULL) {
        return 1; 
    }
    if (L->item < L->prox->item) { 
        return oec(L->prox); 
    } else {
        return 0; 
    }
}


  void ins(Item x, Lista *L) {
      Lista novo = malloc(sizeof(struct no));
      if (novo == NULL) {
          printf("Erro: falha na alocação de memória\n");
          exit(EXIT_FAILURE);
      }
      novo->item = x;
      novo->prox = NULL;

      while (*L != NULL && (*L)->item < x) {
          L = &(*L)->prox;
      }

      novo->prox = *L;
      *L = novo;
  }

  int main(void) {
      Lista A = NULL;
      int tamanho, item;

      printf("Digite o tamanho da lista ordenada: ");
      scanf("%d", &tamanho);

      printf("Digite os %d elementos da lista ordenada:\n", tamanho);
      for (int i = 0; i < tamanho; i++) {
          scanf("%d", &item);
          ins(item, &A);
      }

      if (!oec(A)) {
          printf("A lista ");
          exibe(A);
          printf(" não está ordenada de forma crescente\n");
      } else {
          printf("A lista ");
          exibe(A);
          printf("está ordenada de forma crescente\n");
      }

      return 0;
  }

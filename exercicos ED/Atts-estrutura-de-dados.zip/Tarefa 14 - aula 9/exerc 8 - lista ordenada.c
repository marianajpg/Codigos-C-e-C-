/* Crie a função iterativa rem_todo(x,&L), que remove toda ocorrência do item x na lista
ordenada L.
*/

  #include <stdio.h>
  #include <stdlib.h>

  typedef int Item;

  typedef struct no {
      Item item;
      struct no *prox;
  } *Lista;

  void exibe(Lista L) {
      printf("[");
      if (L != NULL) {
          printf("%d", L->item);
          L = L->prox;
          while (L != NULL) {
              printf(", %d", L->item);
              L = L->prox;
          }
      }
      printf("]\n");
  }

void rem_todo(Item x, Lista *L) {
    Lista *temp;
    while (*L != NULL && (*L)->item < x) {
        L = &(*L)->prox;
    }
    while (*L != NULL && (*L)->item == x) {
        Lista n = *L;
        *L = n->prox;
        free(n);
    }
    if (*L == NULL) {
        return;
    }
    temp = L;
    while ((*temp) != NULL) {
        if ((*temp)->item == x) {
            Lista n = *temp;
            *temp = n->prox;
            free(n);
        } else {
            temp = &(*temp)->prox;
        }
    }
}


  void ins(Item x, Lista *L) {
      Lista novo = malloc(sizeof(struct no));
      if (novo == NULL) {
          printf("Erro: falha na alocação de memória\n");
          exit(EXIT_FAILURE);
      }
      novo->item = x;
      novo->prox = NULL;

      while (*L != NULL && (*L)->item < x) {
          L = &(*L)->prox;
      }

      novo->prox = *L;
      *L = novo;
  }

  int main(void) {
    Lista A = NULL;
    int tamanho, item;

    printf("Digite o tamanho da lista ordenada: ");
    scanf("%d", &tamanho);

    printf("Digite os %d elementos da lista ordenada:\n", tamanho);
    for (int i = 0; i < tamanho; i++) {
        scanf("%d", &item);
        ins(item, &A);
    }
    printf("Digite os elemento que deseja remover da lista ordenada:\n");
    scanf("%d", &item);
      rem_todo(item, &A);
      exibe(A);
      return 0;
  }

/* Crie a função recursiva exiba_rd(L), que exibe a lista ordenada L em ordem direta, i.e.,
mostrando os itens do primeiro até o último (um em cada linha).*/




#include <stdio.h>
#include <stdlib.h>

typedef int Item;

typedef struct no {
    Item item;
    struct no *prox;
} *Lista;


Lista exibe_rd(Lista L) {
  if(L != NULL){
    printf("%d\n", L->item);
    return exibe_rd(L->prox);
    }
  return 0;
}


Lista ins_rec(Item x, Lista *L) {
Lista novo;

if (*L == NULL || x <= (*L)->item) {
    novo = malloc(sizeof(struct no));
    if (novo == NULL) {
        printf("Erro: falha na alocação de memória\n");
        exit(EXIT_FAILURE);
    }
    novo->item = x;
    novo->prox = *L;
    *L = novo;
} else {
    (*L)->prox = ins_rec(x, &((*L)->prox));
}

return *L;
}

int main(void) {
  Lista A = NULL;
  int tamanho, item;

  printf("Digite o tamanho da lista ordenada: ");
  scanf("%d", &tamanho);

  printf("Digite a sequencia de %d elementos:\n", tamanho);
  for (int i = 0; i < tamanho; i++) {
      scanf("%d", &item);
      ins_rec(item, &A);
  }
  printf("\nLista ordenada:\n");
    exibe_rd(A);


return 0;
}

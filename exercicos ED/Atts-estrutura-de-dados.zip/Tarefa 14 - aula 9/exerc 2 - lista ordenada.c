/* Crie a função iterativa ins_isr(x,&L), que insere o item x na lista ordenada L somente se
ele ainda não estiver nesta lista.*/


  #include <stdio.h>
  #include <stdlib.h>

  typedef int Item;

  typedef struct no {
      Item item;
      struct no *prox;
  } *Lista;


  void exibe(Lista L) {
  printf("[");
  if (L != NULL) {
      printf("%d", L->item);
      L = L->prox;
      while (L != NULL) {
          printf(",%d", L->item);
          L = L->prox;
      }
  }
  printf("]\n");
  }


void ins_isr(Item x, Lista *L) {
    Lista novo = malloc(sizeof(struct no));
    if (novo == NULL) {
        printf("Erro: falha na alocação de memória\n");
        exit(EXIT_FAILURE);
    }
    if (*L == NULL || (*L)->item > x) {
        novo->item = x;
        novo->prox = *L;
        *L = novo;
    } else {
        Lista anterior = *L;
        Lista atual = (*L)->prox;
        int encontrado = 0;
        while (atual != NULL && !encontrado) {
            if (atual->item == x) {
                encontrado = 1;
            } else {
                anterior = atual;
                atual = atual->prox;
            }
        }
        if (!encontrado) {
            novo->item = x;
            novo->prox = NULL;
            anterior->prox = novo;
        }
    }
}

int main(void) {
    Lista A = NULL;
    int tamanho, item;
    
    printf("Digite o tamanho da lista ordenada: ");
    scanf("%d", &tamanho);
    
    printf("Digite a sequencia de %d elementos:\n", tamanho);
    for (int i = 0; i < tamanho; i++) {
        scanf("%d", &item);
        ins_isr(item, &A);
    }
  exibe(A);

  
  return 0;
}
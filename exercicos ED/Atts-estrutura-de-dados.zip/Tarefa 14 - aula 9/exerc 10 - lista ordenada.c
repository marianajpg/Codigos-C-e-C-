/* Crie a função recursiva pert_rec(x,L), que verifica se o item x está na lista ordenada L*/



  #include <stdio.h>
  #include <stdlib.h>

  typedef int Item;

  typedef struct no {
      Item item;
      struct no *prox;
  } *Lista;

  void exibe(Lista L) {
      printf("[");
      if (L != NULL) {
          printf("%d", L->item);
          L = L->prox;
          while (L != NULL) {
              printf(", %d", L->item);
              L = L->prox;
          }
      }
      printf("]\n");
  }

int pert_rec(Item x, Lista *L) {
    if( *L == NULL ){
      return 0;
    }
    if((*L)->item == x ) {
      return 1;
    }
  return pert_rec(x, &((*L)->prox));
}


  void ins(Item x, Lista *L) {
      Lista novo = malloc(sizeof(struct no));
      if (novo == NULL) {
          printf("Erro: falha na alocação de memória\n");
          exit(EXIT_FAILURE);
      }
      novo->item = x;
      novo->prox = NULL;

      while (*L != NULL && (*L)->item < x) {
          L = &(*L)->prox;
      }

      novo->prox = *L;
      *L = novo;
  }

  int main(void) {
    Lista A = NULL;
    int tamanho, item;

    printf("Digite o tamanho da lista ordenada: ");
    scanf("%d", &tamanho);

    printf("Digite os %d elementos da lista ordenada:\n", tamanho);
    for (int i = 0; i < tamanho; i++) {
        scanf("%d", &item);
        ins(item, &A);
    }
    printf("Digite o elemento que deseja verificar se está na lista ordenada:\n");
    scanf("%d", &item);
    pert_rec(item, &A);

    if(!pert_rec(item, &A)){
      printf("O elemento %d não está na lista ordenada ", item);
      exibe(A);
    } else{
      printf("O elemento %d está na lista ordenada ", item);
      exibe(A);
    }

    return 0;
  }

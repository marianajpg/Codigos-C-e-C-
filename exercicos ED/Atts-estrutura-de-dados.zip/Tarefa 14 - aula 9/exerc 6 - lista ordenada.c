/* Crie a função recursiva exiba_ri(L), que exibe a lista ordenada L em ordem inversa, i.e.,
mostrando os itens do último até o primeiro (um em cada linha).*/



  #include <stdio.h>
  #include <stdlib.h>

    typedef int Item;

    typedef struct no {
        Item item;
        struct no *prox;
    } *Lista;

  void exibe_ri(Lista L) {
      if (L == NULL) {
          return; 
      }
      exibe_ri(L->prox);
      printf("%d\n", L->item); 
  }

  Lista ins_rec(Item x, Lista *L) {
      Lista novo;

      if (*L == NULL || x <= (*L)->item) {
          novo = malloc(sizeof(struct no));
          if (novo == NULL) {
              printf("Erro: falha na alocação de memória\n");
              exit(EXIT_FAILURE);
          }
          novo->item = x;
          novo->prox = *L;
          *L = novo;
      } else {
          (*L)->prox = ins_rec(x, &((*L)->prox));
      }

      return *L;
  }

  int main(void) {
      Lista A = NULL;
      int tamanho, item;

      printf("Digite o tamanho da lista ordenada: ");
      scanf("%d", &tamanho);

      printf("Digite a sequencia de %d elementos:\n", tamanho);
      for (int i = 0; i < tamanho; i++) {
          scanf("%d", &item);
          ins_rec(item, &A);
      }

      printf("\nLista ordenada inversa:\n");
      exibe_ri(A);

      return 0;
  }

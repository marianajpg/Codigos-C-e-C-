/* Crie a função recursiva ins_rec(x,&L), que insere o item x na lista ordenada L.*/


#include <stdio.h>
#include <stdlib.h>

typedef int Item;

typedef struct no {
    Item item;
    struct no *prox;
} *Lista;


void exibe(Lista L) {
printf("[");
if (L != NULL) {
    printf("%d", L->item);
    L = L->prox;
    while (L != NULL) {
        printf(",%d", L->item);
        L = L->prox;
    }
}
printf("]\n");
}


Lista ins_rec(Item x, Lista *L) {
Lista novo;

if (*L == NULL || x <= (*L)->item) {
    novo = malloc(sizeof(struct no));
    if (novo == NULL) {
        printf("Erro: falha na alocação de memória\n");
        exit(EXIT_FAILURE);
    }
    novo->item = x;
    novo->prox = *L;
    *L = novo;
} else {
    (*L)->prox = ins_rec(x, &((*L)->prox));
}

return *L;
}

int main(void) {
  Lista A = NULL;
  int tamanho, item;

  printf("Digite o tamanho da lista ordenada: ");
  scanf("%d", &tamanho);

  printf("Digite a sequencia de %d elementos:\n", tamanho);
  for (int i = 0; i < tamanho; i++) {
      scanf("%d", &item);
      ins_rec(item, &A);
  }
exibe(A);


return 0;
}

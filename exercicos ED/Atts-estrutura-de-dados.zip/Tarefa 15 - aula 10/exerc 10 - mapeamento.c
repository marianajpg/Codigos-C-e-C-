/* Altere a implementação de mapeamentos para criar mapeamentos em que tanto as chaves
quanto seus valores associados são cadeias de caracteres.
typedef char Chave[22];
typedef char Valor[22];*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef char Chave[22];
typedef char Valor[22];

typedef struct map {
  Chave chave;
  Valor valor;
  struct map *prox;
} *Map;

Map no_map(Chave c, Valor v, Map p) {
  Map n = malloc(sizeof(struct map));
  if (n == NULL) {
    printf("Erro: Falha ao alocar memória.\n");
    exit(EXIT_FAILURE);
  }
  strcpy(n->chave, c);
  strcpy(n->valor, v);
  n->prox = p;
  return n;
}

void insm(Chave c, Valor v, Map *M) {
  *M = no_map(c, v, *M);
}

void destroim(Map M) {
  while (M != NULL) {
    Map temp = M;
    M = M->prox;
    free(temp);
  }
}


void exibem(Map M) {
  printf("[");
  while( M ) {
    printf("(%s,%s)",M->chave,M->valor);
    if( M->prox ) printf(",");
      M = M->prox;
  }
  printf("]\n");
}


int main(void) {
  Map I = NULL;
  int tamanho;
  Chave chave;
  Valor valor;

  printf("Digite a quantidade de chaves que o mapeamento de caracteres terá: ");
  scanf("%d", &tamanho);

  for (int i = 0; i < tamanho; i++) {
    printf("Digite a %dª chave:\n", i+1);
    scanf("%s", chave);
    printf("Digite o valor referente à %dª chave:\n", i+1);
    scanf("%s", valor);
    insm(chave, valor, &I);
  }
    exibem(I);
  destroim(I);
  printf("O mapeamento foi destruído com sucesso!\n");

  return 0;
}
